

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Dashboard</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <!-- -->
    <div class="row">
        <div class="col-lg-3 col-6">
            <div class="small-box bg-info">
                <div class="inner">
                    <h3><?php echo e(count($leads)); ?></h3>
                    <p>Novos Leads</p>
                </div>
                <div class="icon">
                    <i class="fa fa-flag"></i>
                </div>
                <a href="/home" class="small-box-footer">
                    Listar registros <i class="fas fa-arrow-circle-right"></i>
                </a>
            </div>
        </div>
        <div class="col-lg-3 col-6">
            <div class="small-box bg-warning">
                <div class="inner">
                    <h3><?php echo e($leads_waiting); ?></h3>
                    <p>Leads aguardando</p>
                </div>
                <div class="icon">
                    <i class="fa fa-clock"></i>
                </div>
                <a href="<?php echo e(route('admin.leads.tag', ['tag' => 2])); ?>" class="small-box-footer">
                    Listar registros <i class="fas fa-arrow-circle-right"></i>
                </a>
            </div>
        </div>
        <div class="col-lg-3 col-6">
            <div class="small-box bg-success">
                <div class="inner">
                    <h3><?php echo e($leads_converted); ?></h3>
                    <p>Leads convertidos</p>
                </div>
                <div class="icon">
                    <i class="fa fa-thumbs-up"></i>
                </div>
                <a href="<?php echo e(route('admin.clients.tag', ['tag' => 3])); ?>" class="small-box-footer">
                    Listar registros <i class="fas fa-arrow-circle-right"></i>
                </a>
            </div>
        </div>
        <div class="col-lg-3 col-6">
            <div class="small-box bg-danger">
                <div class="inner">
                    <h3><?php echo e($leads_unconverted); ?></h3>
                    <p>Ledas não convertidos</p>
                </div>
                <div class="icon">
                    <i class="fa fa-thumbs-down"></i>
                </div>
                <a href="#" class="small-box-footer">
                    Listar registros <i class="fas fa-arrow-circle-right"></i>
                </a>
            </div>
        </div>
    </div>


    <div class="row">
        <div class="col-md-3 col-sm-6 col-12">
            <div class="info-box shadow-none">
                <span class="info-box-icon bg-info"><i class="far fa-star"></i></span>
                <div class="info-box-content">
                    <span class="info-box-text">Finalizados Procedentes</span>
                    <span class="info-box-number"><?php echo e($procedente); ?></span>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-sm-6 col-12">
            <div class="info-box shadow-lg">
                <span class="info-box-icon bg-danger"><i class="fa fa-thumbs-down"></i></span>
                <div class="info-box-content">
                    <span class="info-box-text">Finalizados Improcedentes</span>
                    <span class="info-box-number"><?php echo e($improcedente); ?></span>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-sm-6 col-12">
            <div class="info-box shadow">
                <span class="info-box-icon bg-warning"><i class="far fa-copy"></i></span>
                <div class="info-box-content">
                    <span class="info-box-text">Obteve Recursos</span>
                    <span class="info-box-number"><?php echo e($resources); ?></span>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-sm-6 col-12">
            <div class="info-box shadow-sm">
                <span class="info-box-icon bg-success"><i class="fa fa-thumbs-up"></i></span>
                <div class="info-box-content">
                    <span class="info-box-text">Auto Findos</span>
                    <span class="info-box-number">0</span>
                </div>
            </div>
        </div>
    </div>

    <!-- -->
    <div class="row">
        <div class="col-md-9 col-12">

            <?php if(session('success')): ?>
                <div id="message" class="alert alert-success mb-2" role="alert">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Lista de novos leads de atendimento</h3>
                            <div class="card-tools">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create-lead')): ?>
                                    <a href="" class="btn btn-sm btn-info btn-block" data-toggle="modal"
                                        data-target="#modal-xl">
                                        <i class="fa fa-plus mr-1"></i> Adicionar lead
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="card-body table-responsive p-0" style="height: 300px;">
                            <table class="table table-hover table-striped  table-head-fixed">
                                <thead>
                                    <tr>
                                        <th class="py-2">Franqueado</th>
                                        <th class="py-2">Nome</th>
                                        <th class="py-2 px-2" style="width: 50px;"></th>
                                        <th class="py-2 px-2" style="width: 70px;"></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td class="py-2">
                                                <p class="m-0" style="line-height: 1">
                                                    <?php echo e($lead->user->name); ?><br />
                                                    <?php if(isset($lead->user->phone)): ?>
                                                        <small><?php echo e($lead->user->phone); ?></small>
                                                    <?php endif; ?>
                                                </p>
                                            </td>
                                            <td class="py-2">
                                                <p class="m-0" style="line-height: 1"><?php echo e($lead->name); ?><br />
                                                    <small>
                                                        <?php echo e($lead->phone); ?> -
                                                        <?php if(isset($lead->address)): ?>
                                                            <?php echo e($lead->address); ?>, <?php echo e($lead->number); ?>,
                                                            <?php echo e($lead->district); ?>, <?php echo e($lead->city); ?>,
                                                            <?php echo e($lead->state); ?>

                                                        <?php endif; ?>
                                                    </small>
                                                </p>
                                            </td>
                                            <td class="py-2 px-0">
                                                <a href="<?php echo e(route('admin.leads.show', ['id' => $lead->id])); ?>"
                                                    class="btn btn-block btn-success btn-sm" title="Comentários do lead">
                                                    <i class="fa fa-comments"></i> <?php echo e(count($lead->feedbackLeads)); ?>

                                                </a>
                                            </td>
                                            <td class="py-2 px-2">
                                                <a href="<?php echo e(route('admin.leads.edit', ['id' => $lead->id])); ?>"
                                                    class="btn btn-block btn-info btn-sm" title="Alterar registro">
                                                    <i class="fa fa-edit"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="5" class="text-center">
                                                <span>Nenhum lead adicionado.</span>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4 col-12">
                    <div class="card card-danger">
                        <div class="card-header">
                            <h3 class="card-title"><i class="fa fa-hourglass-end mr-1" aria-hidden="true"></i> Prazos não
                                cumpridos</h3>
                        </div>
                        <div class="card-body p-0">
                            <table class="table table-hover table-striped table-head-fixed">
                                <thead>
                                    <tr>
                                        <th class="py-2">Cliente</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $terms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $term): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(\Carbon\Carbon::now()->format('Y-m-d') > $term->term && $term->tag == 1): ?>
                                            <tr>
                                                <td class="py-2">
                                                    <p class="m-0" style="line-height: 1">
                                                        <small><?php echo e(\Carbon\Carbon::parse($term->term)->format('d/m/Y')); ?></small><br />
                                                        <a href="<?php echo e(route('admin.terms.edit', ['id' => $term->id])); ?>">
                                                            <?php echo e($term->lead->name); ?>

                                                        </a>
                                                    </p>
                                                </td>
                                            </tr>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-12">
                    <div class="card card-success">
                        <div class="card-header">
                            <h3 class="card-title"><i class="fa fa-bell" aria-hidden="true"></i> Lembretes</h3>
                        </div>
                        <div class="card-body p-0">
                            <table class="table table-hover table-striped table-head-fixed">
                                <thead>
                                    <tr>
                                        <th class="py-2">Cliente</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $reminders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reminder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="py-2">

                                                <p class="m-0" style="line-height: 1">
                                                    <a href="<?php echo e(route('admin.clients.edit', ['id' => $reminder->id])); ?>">
                                                        <?php echo e($reminder->name); ?>

                                                    </a><br />
                                                    <small>
                                                        <?php if($reminder->tag == 1): ?>
                                                            Aguardando
                                                        <?php elseif($reminder->tag == 2): ?>
                                                            Convertdo
                                                        <?php else: ?>
                                                            Não convertodo
                                                        <?php endif; ?>
                                                    </small>
                                                </p>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-12">
                    <div class="card card-warning">
                        <div class="card-header">
                            <h3 class="card-title"><i class="fa fa-tag mr-1"></i> Tickets abertos</h3>
                        </div>
                        <div class="card-body p-0">
                            <table class="table table-hover table-striped table-head-fixed">
                                <thead>
                                    <tr>
                                        <th class="py-2">Franqueado</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="py-2">
                                                <p class="m-0" style="line-height: 1">
                                                    <small><?php echo e(\Carbon\Carbon::parse($ticket->created_at)->format('d/m/Y H:m:s')); ?></small><br />
                                                    <a href="<?php echo e(route('admin.tickets.index')); ?>">
                                                        <?php echo e($ticket->user->name); ?>

                                                    </a>
                                                </p>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-12">
                    <div class="card card-danger" style="transition: all 0.15s ease 0s; height: inherit; width: inherit;">
                        <div class="card-header">
                            <h3 class="card-title">Pagamentos vencidos</h3>
                            <div class="card-tools">

                            </div>
                        </div>
                        <div class="card-body table-responsive p-0">
                            <table class="table table-hover table-striped table-head-fixed">
                                <thead>
                                    <tr>
                                        <th class="py-2">Data</th>
                                        <th class="py-2">Franqueado</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $installments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(\Carbon\Carbon::now()->format('Y-m-d') > $value->date && $value->active == 'N'): ?>
                                            <tr>
                                                <td class="py-2">
                                                    <a
                                                        href="<?php echo e(route('admin.financials.edit', ['id' => $value->financial_id])); ?>">
                                                        <?php echo e(\Carbon\Carbon::parse($value->date)->format('d/m/Y')); ?>

                                                    </a>
                                                </td>
                                                <td class="py-2"><?php echo e($value->financial->user->name); ?></td>
                                            </tr>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-12">
                    <div class="card card-success"
                        style="transition: all 0.15s ease 0s; height: inherit; width: inherit;">
                        <div class="card-header">
                            <h3 class="card-title">Data Cessações:</h3>
                            <div class="card-tools">

                            </div>
                        </div>
                        <div class="card-body table-responsive p-0">
                            <table class="table table-hover table-striped table-head-fixed">
                                <thead>
                                    <tr>
                                        <th class="py-2">Cliente</th>
                                        <th class="py-2">Cessação</th>
                                        <th class="py-2"></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $administratives; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="py-2"><?php echo e($value->name); ?></td>
                                            <td class="py-2">
                                                <a href="<?php echo e(route('admin.administratives.edit', ['id' => $value->id])); ?>">
                                                    <?php echo e(\Carbon\Carbon::parse($value->concessao_date)->format('d/m/Y')); ?>

                                                </a>
                                            </td>
                                            <td class="py-2">
                                                <?php
                                                    $end = \Carbon\Carbon::parse($value->concessao_date);
                                                    $now = \Carbon\Carbon::now();
                                                    $diff = $end->diffInDays($now);
                                                    echo $diff . ' dias.';
                                                ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-12">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('confirm-payment')): ?>
                        <div class="card card-success"
                            style="transition: all 0.15s ease 0s; height: inherit; width: inherit;">
                            <div class="card-header">
                                <h3 class="card-title">Pagamentos Realizados</h3>
                                <div class="card-tools">

                                </div>
                            </div>
                            <div class="card-body table-responsive p-0">
                                <table class="table table-hover table-striped table-head-fixed">
                                    <thead>
                                        <tr>
                                            <th class="py-2">Data</th>
                                            <th class="py-2">Franqueado</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $installments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($value->active == 'S'): ?>
                                                <tr>
                                                    <td class="py-2">
                                                        <a
                                                            href="<?php echo e(route('admin.financials.edit', ['id' => $value->financial_id])); ?>">
                                                            <?php echo e(\Carbon\Carbon::parse($value->date)->format('d/m/Y')); ?>

                                                        </a>
                                                    </td>
                                                    <td class="py-2"><?php echo e($value->financial->user->name); ?></td>
                                                </tr>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

        </div>

        <div class="col-md-3 col-12">






            <div class="timeline">
                <div class="time-label">
                    <span class="bg-green">Confira os Eventos</span>
                </div>
                <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(\Carbon\Carbon::now()->format('Y-m-d') < $event->date): ?>
                        <div>
                            <i class="fas fa-bell bg-blue"></i>
                            <div class="timeline-item">
                                <?php if(isset($event->image)): ?>
                                    <img src="<?php echo e(asset('storage/' . $event->image)); ?>" alt="photo" style="width: 100%" />
                                <?php endif; ?>
                                <span class="time"><i class="fas fa-calendar"></i>
                                    <?php echo e(\Carbon\Carbon::parse($event->date)->format('d/m/Y')); ?></span>
                                <h3 class="timeline-header text-bold"><?php echo e($event->title); ?></h3>
                                <div class="timeline-body">
                                    <?php echo e($event->description); ?>

                                </div>
                                <div class="timeline-footer">
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <div>
                    <i class="fas fa-clock bg-gray"></i>
                </div>
            </div>

        </div>
    </div>

    <div class="modal fade" id="modal-xl" style="display: none;" aria-hidden="true">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header bg-info">
                    <h4 class="modal-title">Lead de atendimento</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <form method="POST" action="<?php echo e(route('home.store')); ?>" onsubmit="return mySubmit()">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group m-0">
                                    <small>Nome: *</small>
                                    <input type="text" name="name" value="<?php echo e(old('name')); ?>"
                                        class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" maxlength="100" />
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-red"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-sm-3">
                                <div class="form-group m-0">
                                    <small>Telefones: *</small>
                                    <input type="text" name="phone" value="<?php echo e(old('phone')); ?>"
                                        class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" maxlength="50" />
                                    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-red"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-sm-3">
                                <div class="form-group m-0">
                                    <small>Franqueado: *</small>
                                    <select name="user_id" class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                        <option value="">Selecione um franqueado</option>
                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-red"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-sm-3">
                                <div class="form-group m-0">
                                    <small>Cep:</small>
                                    <input type="text" name="zip_code" id="cep" value="<?php echo e(old('zip_code')); ?>"
                                        class="form-control <?php $__errorArgs = ['zip_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" maxlength="9"
                                        onkeypress="mascara(this, '#####-###')" onblur="pesquisacep(this.value);" />
                                    <?php $__errorArgs = ['zip_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-red"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-sm-9">
                                <div class="form-group m-0">
                                    <small>Endereço:</small>
                                    <input type="text" name="address" id="address" value="<?php echo e(old('address')); ?>"
                                        class="form-control <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" maxlength="250" />
                                    <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-red"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-sm-2">
                                <div class="form-group m-0">
                                    <small>Número:</small>
                                    <input type="text" name="number" value="<?php echo e(old('number')); ?>"
                                        class="form-control <?php $__errorArgs = ['number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="nº"
                                        maxlength="5" />
                                    <?php $__errorArgs = ['number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-red"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="form-group m-0">
                                    <small>Bairro:</small>
                                    <input type="text" name="district" id="district" value="<?php echo e(old('district')); ?>"
                                        class="form-control <?php $__errorArgs = ['district'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" maxlength="50" />
                                    <?php $__errorArgs = ['district'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-red"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="form-group m-0">
                                    <small>Cidade:</small>
                                    <input type="text" name="city" id="city" value="<?php echo e(old('city')); ?>"
                                        class="form-control <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" maxlength="50" />
                                    <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-red"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-sm-2">
                                <div class="form-group m-0">
                                    <small>Estado:</small>
                                    <input type="text" name="state" id="state" value="<?php echo e(old('state')); ?>"
                                        class="form-control <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" maxlength="2" />
                                    <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-red"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <div class="form-group m-0">
                                    <small>Comentários:</small>
                                    <textarea name="comments" class="form-control" placeholder="Digite aqui o seu comentário."><?php echo e(old('comments')); ?></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer justify-content-between">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>
                        <button id=button type="submit" class="btn btn-info">
                            <i class="fa fa-save mr-1"></i> Salvar registro
                        </button>
                        <a id="spinner" class="btn btn-md btn-info float-right text-center" style="display: none;">
                            <div id="spinner" class="spinner-border" role="status"
                                style="width: 20px; height: 20px;">
                                <span class="sr-only">Loading...</span>
                            </div>
                            Enviando...
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        document.getElementById("button").style.display = "block";
        document.getElementById("spinner").style.display = "none";

        function mySubmit() {
            document.getElementById("button").style.display = "none";
            document.getElementById("spinner").style.display = "block";
        }

        setTimeout(() => {
            document.getElementById('message').style.display = 'none';
        }, 6000);

        //criação de mascara
        function mascara(t, mask) {
            var i = t.value.length;
            var saida = mask.substring(1, 0);
            var texto = mask.substring(i)
            if (texto.substring(0, 1) != saida) {
                t.value += texto.substring(0, 1);
            }
        }

        // Busca pelo cep
        function limpa_formulario_cep() {
            //Limpa valores do formulário de cep.
            document.getElementById('address').value = ("");
            document.getElementById('district').value = ("");
            document.getElementById('city').value = ("");
            document.getElementById('state').value = ("");
        }

        function meu_callback(conteudo) {
            if (!("erro" in conteudo)) {
                //Atualiza os campos com os valores.
                document.getElementById('address').value = (conteudo.logradouro);
                document.getElementById('district').value = (conteudo.bairro);
                document.getElementById('city').value = (conteudo.localidade);
                document.getElementById('state').value = (conteudo.uf);
            } else {
                //CEP não Encontrado.
                limpa_formulário_cep();
                alert("CEP não encontrado.");
            }
        }

        function pesquisacep(valor) {
            //Nova variável "cep" somente com dígitos.
            var cep = valor.replace(/\D/g, '');
            //Verifica se campo cep possui valor informado.
            if (cep != "") {
                //Expressão regular para validar o CEP.
                var validacep = /^[0-9]{8}$/;
                //Valida o formato do CEP.
                if (validacep.test(cep)) {
                    //Preenche os campos com "..." enquanto consulta webservice.
                    document.getElementById('address').value = "...";
                    document.getElementById('district').value = "...";
                    document.getElementById('city').value = "...";
                    document.getElementById('state').value = "...";
                    //Cria um elemento javascript.
                    var script = document.createElement('script');
                    //Sincroniza com o callback.
                    script.src = 'https://viacep.com.br/ws/' + cep + '/json/?callback=meu_callback';
                    //Insere script no documento e carrega o conteúdo.
                    document.body.appendChild(script);

                } else {
                    //cep é inválido.
                    limpa_formulário_cep();
                    alert("Formato de CEP inválido.");
                }
            } //end if.
            else {
                //cep sem valor, limpa formulário.
                limpa_formulário_cep();
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\idprevinss\resources\views/home.blade.php ENDPATH**/ ?>