

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <div class="d-flex justify-content-between">
        <div>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('search-client')): ?>
                <form method="GET" action="<?php echo e(route('admin.clients.index')); ?>">
                    <div class="input-group input-group-md">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-franchisee')): ?>
                            <select name="franchisee" class="form-control mr-1">
                                <option value="">Franqueado</option>
                                <?php $__currentLoopData = $franchisees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        <?php endif; ?>
                        <select name="situation" class="form-control mr-1">
                            <option value="">Situação</option>
                            <option value="1">Andamento em ordem</option>
                            <option value="2">Aguardando cumprimento</option>
                            <option value="3">Finalizado Procedente</option>
                            <option value="4">Finalizado Improcedente</option>
                            <option value="5">Recursos</option>
                        </select>
                        <input type="text" name="search" class="form-control" placeholder="Cliente">
                        <span class="input-group-append">
                            <button type="submit" class="btn btn-info btn-flat">
                                <i class="fa fa-search mr-1"></i> Buscar
                            </button>
                        </span>
                    </div>
                </form>
            <?php endif; ?>
        </div>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create-client')): ?>
            <a href="<?php echo e(route('admin.clients.create')); ?>" class="btn btn-md btn-info" title="Adicionar novo registro">
                <i class="fa fa-plus mr-1"></i> Adicionar novo
            </a>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- -->
    <div class="row">
        <div class="col-lg-3 col-6">
            <div class="small-box bg-info">
                <div class="inner">
                    <h3><?php echo e($totals); ?></h3>
                    <p>Clientes</p>
                </div>
                <div class="icon">
                    <i class="fa fa-users"></i>
                </div>
                <a href="<?php echo e(route('admin.clients.index')); ?>" class="small-box-footer">
                    Listar registros <i class="fas fa-arrow-circle-right"></i>
                </a>
            </div>
        </div>
        <div class="col-lg-3 col-6">
            <div class="small-box bg-warning">
                <div class="inner">
                    <h3><?php echo e($waiting); ?></h3>
                    <p>Leads aguardando</p>
                </div>
                <div class="icon">
                    <i class="fa fa-clock"></i>
                </div>
                <?php if($waiting > 0): ?>
                    <a href="<?php echo e(route('admin.leads.tag', ['tag' => 2])); ?>" class="small-box-footer">
                        Listar registros <i class="fas fa-arrow-circle-right"></i>
                    </a>
                <?php else: ?>
                    <a class="small-box-footer">
                        &nbsp;
                    </a>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-lg-3 col-6">
            <div class="small-box bg-success">
                <div class="inner">
                    <h3><?php echo e($converted_lead); ?></h3>
                    <p>Clientes convertidos</p>
                </div>
                <div class="icon">
                    <i class="fa fa-thumbs-up"></i>
                </div>
                <?php if($converted_lead > 0): ?>
                    <a href="<?php echo e(route('admin.clients.tag', ['tag' => 3])); ?>" class="small-box-footer">
                        Listar registros <i class="fas fa-arrow-circle-right"></i>
                    </a>
                <?php else: ?>
                    <a class="small-box-footer">
                        &nbsp;
                    </a>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-lg-3 col-6">
            <div class="small-box bg-danger">
                <div class="inner">
                    <h3><?php echo e($unconverted_lead); ?></h3>
                    <p>Clientes não convertidos</p>
                </div>
                <div class="icon">
                    <i class="fa fa-thumbs-down"></i>
                </div>
                <?php if($unconverted_lead > 0): ?>
                    <a href="<?php echo e(route('admin.clients.tag', ['tag' => 4])); ?>" class="small-box-footer">
                        Listar registros <i class="fas fa-arrow-circle-right"></i>
                    </a>
                <?php else: ?>
                    <a class="small-box-footer">
                        &nbsp;
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- -->
    <div class="row">
        <div class="col-md-3 col-sm-6 col-12">
            <div class="info-box shadow-none">
                <span class="info-box-icon bg-info"><i class="far fa-star"></i></span>
                <div class="info-box-content">
                    <span class="info-box-text">Finalizados Procedentes</span>
                    <span class="info-box-number"><?php echo e($procedente); ?></span>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-sm-6 col-12">
            <div class="info-box shadow-lg">
                <span class="info-box-icon bg-danger"><i class="fa fa-thumbs-down"></i></span>
                <div class="info-box-content">
                    <span class="info-box-text">Finalizados Improcedentes</span>
                    <span class="info-box-number"><?php echo e($improcedente); ?></span>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-sm-6 col-12">
            <div class="info-box shadow">
                <span class="info-box-icon bg-warning"><i class="far fa-copy"></i></span>
                <div class="info-box-content">
                    <span class="info-box-text">Obteve Recursos</span>
                    <span class="info-box-number"><?php echo e($resources); ?></span>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-sm-6 col-12">
            <div class="info-box shadow-sm">
                <span class="info-box-icon bg-success"><i class="fa fa-thumbs-up"></i></span>
                <div class="info-box-content">
                    <span class="info-box-text">Auto Findos</span>
                    <span class="info-box-number"><?php echo e($findos); ?></span>
                </div>
            </div>
        </div>
    </div>

    <?php if(session('success')): ?>
        <div id="message" class="alert alert-success mb-2" role="alert">
            <?php echo e(session('success')); ?>

        </div>
    <?php elseif(session('alert')): ?>
        <div id="message" class="alert alert-warning mb-2" role="alert">
            <?php echo e(session('alert')); ?>

        </div>
    <?php elseif(session('error')): ?>
        <div id="message" class="alert alert-danger mb-2" role="alert">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <!-- -->
    <div class="row">
        <div class="col-md-9 col-12">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Lista de clientes convertidos não finalizados</h3>
                            <div class="card-tools">

                            </div>
                        </div>

                        <div class="card-body table-responsive p-0">
                            <table class="table table-hover table-striped  table-head-fixed">
                                <thead>
                                    <tr>
                                        <th class="py-2">Franqueado</th>
                                        <th>Advogado(s)</th>
                                        <th class="py-2">Cliente</th>
                                        <th class="py-2">Situação</th>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('terms-client')): ?>
                                            <th class="py-2 px-2" style="width: 70px;">Prazos</th>
                                        <?php endif; ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('comments-client')): ?>
                                            <th class="py-2 px-2" style="width: 70px;">Comts</th>
                                        <?php endif; ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-client')): ?>
                                            <th class="py-2 px-2" style="width: 70px;">Edit</th>
                                        <?php endif; ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-client')): ?>
                                            <th class="py-2 px-2" style="width: 70px;">Del</th>
                                        <?php endif; ?>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td>
                                                <p class="m-0" style="line-height: 1">
                                                    <?php echo e($lead->user->name); ?><br />
                                                    <small>
                                                        <?php if(isset($lead->user->phone)): ?>
                                                            <?php echo e($lead->user->phone); ?> - 
                                                        <?php endif; ?>
                                                        <?php echo e($lead->user->email); ?>

                                                    </small>
                                                </p>
                                            </td>
                                            <td>
                                                <div class="row">
                                                    <?php $__currentLoopData = $lead->lawyers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lawyer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                                                        <div class="col-md-3">
                                                            <?php if(isset($lawyer->image)): ?>
                                                                <img alt="Avatar" class="img-circle img-size-32" src="<?php echo e(asset('storage/'.$lawyer->image)); ?>" style="width: 32px; height: 32px;" title="<?php echo e($lawyer->name); ?>">
                                                            <?php else: ?>
                                                                <img alt="Avatar" class="img-circle img-size-32" src="https://dummyimage.com/28x28/b6b7ba/fff" title="<?php echo e($lawyer->name); ?>">
                                                            <?php endif; ?>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            </td>
                                            <td>
                                                <p class="m-0" style="line-height: 1">
                                                    <?php echo e($lead->name); ?><br/>
                                                    <small>
                                                        <?php echo e($lead->phone); ?> - 
                                                        <?php if(isset($lead->address)): ?>
                                                            <?php echo e($lead->address); ?>, <?php echo e($lead->number); ?>,
                                                                <?php echo e($lead->district); ?>, <?php echo e($lead->city); ?>,
                                                                <?php echo e($lead->state); ?>

                                                        <?php endif; ?>
                                                    </small>
                                                </p>
                                            </td>
                                            <td>
                                                <?php
                                                    $array_situations = [1 => 'Andamento em ordem', 2 => 'Aguardando cumprimento', 3 => 'Finalizado procedente', 4 => 'Finalizado improcedente', 5 => 'Recursos'];
                                                    foreach ($array_situations as $key => $value) {
                                                        if ($key == $lead->situation) {
                                                            echo '<span>' . $value . '</span>';
                                                        }
                                                    }
                                                ?>
                                            </td>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('terms-client')): ?>
                                                <td class='px-1'>
                                                    <a href="#" class="btn btn-sm border btn-block"
                                                        title="Prazos a cumprir" data-toggle="modal"
                                                        data-target="#modal-xl<?php echo e($lead->id); ?>">
                                                        <i class="fa fa-clock"></i> <?php echo e(count($lead->terms)); ?>

                                                    </a>
                                                </td>
                                            <?php endif; ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('comments-client')): ?>
                                                <td class='px-1'>
                                                    <a href="<?php echo e(route('admin.clients.show', ['id' => $lead->id])); ?>"
                                                        title="Comentários do cliente" class="btn btn-sm border btn-block"><i
                                                            class="fa fa-comments"></i>
                                                        <?php echo e(count($lead->feedbackLeads)); ?>

                                                    </a>
                                                </td>
                                            <?php endif; ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-client')): ?>
                                                <td class='px-1'>
                                                    <a href="<?php echo e(route('admin.clients.edit', ['id' => $lead->id])); ?>"
                                                        title="Alterar registro" class="btn btn-info btn-sm btn-block">
                                                        <i class="fas fa-edit"></i>
                                                    </a>
                                                </td>
                                            <?php endif; ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-client')): ?>
                                                <td class='px-1'>
                                                    <form method="POST" onsubmit="return(confirmaExcluir())"
                                                        action="<?php echo e(route('admin.clients.destroy', ['id' => $lead->id])); ?>">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" class="btn btn-danger btn-sm btn-block"
                                                            title="Excluir registro">
                                                            <i class="fas fa-trash"></i>
                                                        </button>
                                                    </form>
                                                </td>
                                            <?php endif; ?>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="8" class="text-center">Nenhum registro encontrado</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        <?php if($leads): ?>
                            <div class="card-footer">
                                <?php echo e($leads->links()); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <?php $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="modal fade" id="modal-xl<?php echo e($lead->id); ?>" style="display: none;" aria-hidden="true">
                    <div class="modal-dialog modal-xl">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h4 class="modal-title">Prazos</h4>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">×</span>
                                </button>
                            </div>
                            <div class="modal-body p-0">
                                <table class="table table-hover table-striped  table-head-fixed">
                                    <thead>
                                        <tr>
                                            <th>Comentário</th>
                                            <th>Prazo</th>
                                            <th>Audiência</th>
                                            <th>Endereço</th>
                                            <th>Status</th>
                                            <th class="py-2 px-2" style="width: 70px;">Edit</th>
                                            <th class="py-2 px-2" style="width: 70px;">Del</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $lead->terms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $term): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <td><?php echo e($term->comments); ?></td>
                                                <td><?php echo e(\Carbon\Carbon::parse($term->term)->format('d/m/Y')); ?></td>
                                                <td>
                                                    <?php if(isset($term->audiencia)): ?>
                                                        <?php echo e(\Carbon\Carbon::parse($term->audiencia)->format('d/m/Y')); ?>

                                                    <?php endif; ?>
                                                    <?php if(isset($term->hour)): ?>
                                                        as <?php echo e($term->hour); ?>

                                                    <?php endif; ?>
                                                </td>
                                                <td><?php echo e($term->address); ?></td>
                                                <td>
                                                    <?php if($term->tag == 1): ?>
                                                        <span>Aguardando</span>
                                                    <?php else: ?>
                                                        <span>Cumprido</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td class='px-1'>
                                                    <a href="<?php echo e(route('admin.terms.edit', ['id' => $term->id])); ?>"
                                                        class="btn btn-info btn-xs btn-block">
                                                        <i class="fas fa-edit"></i>
                                                    </a>
                                                </td>
                                                <td class='px-1'>
                                                    <form method="POST" onsubmit="return(confirmaExcluir())"
                                                        action="<?php echo e(route('admin.terms.delete', ['id' => $term->id])); ?>">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" class="btn btn-danger btn-xs btn-block">
                                                            <i class="fas fa-trash"></i>
                                                        </button>
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <tr>
                                                <td colspan="8" class="text-center">Nenhum registro encontrado</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="modal-footer justify-content-between">
                                <button type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>
                                <a href="<?php echo e(route('admin.terms.create', ['id' => $lead->id])); ?>" class="btn btn-primary">
                                    <i class="fa fa-plus mr-1"></i> Adicionar Prazo
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
        <div class="col-md-3 col-12">

            <div class="card card-danger">
                <div class="card-header">
                    <h3 class="card-title">Parcelas Vencidas</h3>
                </div>
                <div class="card-body p-0">
                    <table class="table table-hover table-striped table-head-fixed">
                        <thead>
                            <tr>
                                <th class="py-2">Data</th>
                                <th class="py-2">Franqueado</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $installments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(\Carbon\Carbon::now()->format('Y-m-d') > $value->date && $value->active == 'S'): ?>
                                    <tr>
                                        <td class="py-2">
                                            <a
                                                href="<?php echo e(route('admin.financials.edit', ['id' => $value->financial_id])); ?>">
                                                <?php echo e(\Carbon\Carbon::parse($value->date)->format('d/m/Y')); ?>

                                            </a>
                                        </td>
                                        <td class="py-2"><?php echo e($value->financial->user->name); ?></td>
                                    </tr>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="card card-danger">
                <div class="card-header">
                    <h3 class="card-title">Prazos não cumpridos</h3>
                </div>
                <div class="card-body p-0">
                    <table class="table table-hover table-striped table-head-fixed">
                        <thead>
                            <tr>
                                <th class="py-2">Data</th>
                                <th class="py-2">Cliente</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $terms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $term): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(\Carbon\Carbon::now()->format('Y-m-d') > $term->term && $term->tag == 1): ?>
                                    <tr>
                                        <td class="py-2">
                                            <a
                                                href="<?php echo e(route('admin.terms.edit', ['id' => $term->id])); ?>"><?php echo e(\Carbon\Carbon::parse($term->term)->format('d/m/Y')); ?></a>
                                        </td>
                                        <td class="py-2"><?php echo e($term->lead->name); ?></td>
                                    </tr>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="card card-warning">
                <div class="card-header">
                    <h3 class="card-title">Lembrete de clientes</h3>
                </div>
                <div class="card-body p-0">
                    <table class="table table-hover table-striped table-head-fixed">
                        <thead>
                            <tr>
                                <th class="py-2">Cliente</th>
                                <th class="py-2">Situação</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($value->confirmed == 1): ?>
                                    <tr>
                                        <td class="py-2">
                                            <a
                                                href="<?php echo e(route('admin.clients.edit', ['id' => $value->id])); ?>"><?php echo e($value->name); ?></a>
                                        </td>
                                        <td class="py-2">
                                            <?php
                                                $array_situations = [1 => 'Andamento em ordem', 2 => 'Aguardando cumprimento', 3 => 'Finalizado procedente', 4 => 'Finalizado improcedente', 5 => 'Recursos'];
                                                foreach ($array_situations as $key => $item) {
                                                    if ($key == $value->situation) {
                                                        echo '<span>' . $item . '</span>';
                                                    }
                                                }
                                            ?>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        function confirmaExcluir() {
            var conf = confirm("Deseja mesmo excluir? Os dados serão perdidos e não poderão ser recuperados.");
            if (conf) {
                return true;
            } else {
                return false;
            }
        }

        setTimeout(() => {
            document.getElementById('message').style.display = 'none';
        }, 6000);
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\idprevinss\resources\views/admin/clients/index.blade.php ENDPATH**/ ?>